import "./App.css";
import { useState, useEffect } from "react";
import {getAll ,search} from "./BooksAPI";


function App() {
  const [showSearchPage, setShowSearchpage] = useState(false);
  const [TextSearch, setTextSearch] = useState("");
  const [books, setBooks] = useState([]);
  const [CurentBooks, setCurentBooks] = useState([]);
  const ChangeBook =(e,selectedBook)=>{
    const {value} = e.target;
    let changedBooks = CurentBooks;
      changedBooks.forEach((book,idx)=>{
  if(selectedBook.title ===book.title){
  book.shelf=value;
  }
  })
  setCurentBooks([...changedBooks]);
  localStorage.setItem("Books", JSON.stringify(changedBooks));
}
const addBook =(e,selectedBook)=>{
  const {  value } = e.target;
  let changedBooks = CurentBooks;
selectedBook.shelf= value
changedBooks.push(selectedBook);
setCurentBooks([...changedBooks]);
localStorage.setItem("Books", JSON.stringify(changedBooks));
}
  const getBooks = ()=>{
    getAll()
    .then((response) => {
      setCurentBooks(response);
    })
    .catch((error) => { });
    }
    const searchBooks= (text)=>{
      search(text)
      .then((response) => {
        if(response && response.length>0){
        setBooks(response);
        }else{
          setBooks([]);
        }
      })
        .catch((error) => { });
      };
    useEffect(() => {
      let Books = localStorage.getItem("Books");
      if(Books)
        {let getBook = JSON.parse(Books);
        setCurentBooks(getBook)}
        else{getBooks();}
  }, [0]);
  useEffect(() => {
    if(TextSearch){searchBooks(TextSearch);}
    
}, [TextSearch]);
  return (
    <div className="app">
      {showSearchPage ? (
        <div className="search-books">
          <div className="search-books-bar">
            <button
              className="close-search"
              onClick={() => setShowSearchpage(!showSearchPage)}
            >
              Close
            </button>
            <div className="search-books-input-wrapper">
              <input
                value={TextSearch}
                onChange={(e)=> setTextSearch(e.target.value)
                }
                type="text"
                placeholder="Search by title, author, or ISBN"
              />
            </div>
          </div>
          <div className="search-books-results">
            <ol className="books-grid">
            {books.map((book, index)=>{return (<li><div className="book">
                        <div className="book-top">
                          <div className="book-cover"
                            style={{
                              width: 128,
                              height: 188,
                              backgroundImage:
                                `url(${book.imageLinks?.thumbnail})`,
                            }}
                          ></div>
                          <div className="book-shelf-changer">
                            <select value={"none"} onChange={(e)=>addBook(e,book)
                              }>
                              <option value="none" disabled>
                                Move to...
                              </option>
                              <option value="currentlyReading">Currently Reading</option>
                              <option  value="wantToRead">Want to Read</option>
                              <option value="read">Read</option>
                              <option value="none">None</option>
                            </select>
                          </div>
                        </div>
                        <div className="book-title">{book.title}</div>
                        <div className="book-authors">{book.authors}</div>
                      </div></li>)})}
            </ol>
          </div>
        </div>
      ) : (
        <div className="list-books">
          <div className="list-books-title">
            <h1>MyReads</h1>
          </div>
          <div className="list-books-content">
            <div>
              <div className="bookshelf">
                <h2 className="bookshelf-title">Currently Reading</h2>
                <div className="bookshelf-books">
                  <ol className="books-grid">
                  {CurentBooks.map((book, index)=>{return (book.shelf==="currentlyReading"&&<li><div className="book">
                        <div className="book-top">
                          <div
                            className="book-cover"
                            style={{
                              width: 128,
                              height: 188,
                              backgroundImage:
                                `url(${book.imageLinks.thumbnail})`,
                            }}
                          ></div>
                          <div className="book-shelf-changer">
                            <select value={"none"} onChange={(e)=>ChangeBook(e,book)
                              }>
                              <option value="none" disabled>
                                Move to...
                              </option>
                              <option value="currentlyReading">
                                Currently Reading
                              </option>
                              <option value="wantToRead">Want to Read</option>
                              <option value="read">Read</option>
                              <option value="none">None</option>
                            </select >
                          </div>
                        </div>
                        <div className="book-title">{book.title}</div>
                        <div className="book-authors">{book.authors[0]}</div>
                      </div></li>)})}
                  </ol>
                </div>
              </div>
              <div className="bookshelf">
                <h2 className="bookshelf-title">Want to Read</h2>
                <div className="bookshelf-books">
                  <ol className="books-grid">
                  {CurentBooks.map((book, index)=>{return (book.shelf==="wantToRead"&&<li><div className="book">
                        <div className="book-top">
                          <div
                            className="book-cover"
                            style={{
                              width: 128,
                              height: 188,
                              backgroundImage:
                                `url(${book.imageLinks.thumbnail})`,
                            }}
                          ></div>
                          <div className="book-shelf-changer">
                            <select value={"none"} onChange={(e)=>ChangeBook(e,book)
                              }>
                              <option value="none" disabled>
                                Move to...
                              </option>
                              <option value="currentlyReading">
                                Currently Reading
                              </option>
                              <option  value="wantToRead">Want to Read</option>
                              <option value="read">Read</option>
                              <option value="none">None</option>
                            </select>
                          </div>
                        </div>
                        <div className="book-title">{book.title}</div>
                        <div className="book-authors">{book.authors[0]}</div>
                      </div></li>)})}
                  </ol>
                </div>
              </div>
              <div className="bookshelf">
                <h2 className="bookshelf-title">Read</h2>
                <div className="bookshelf-books">
                  <ol className="books-grid">
                  {CurentBooks.map((book, index)=>{return (book.shelf==="read"&&<li><div className="book">
                        <div className="book-top">
                          <div
                            className="book-cover"
                            style={{
                              width: 128,
                              height: 188,
                              backgroundImage:
                                `url(${book.imageLinks.thumbnail})`,
                            }}
                          ></div>
                          <div className="book-shelf-changer">
                            <select value={"none"} onChange={(e)=>ChangeBook(e,book)
                              }>
                              <option value="none" disabled>
                                Move to...
                              </option>
                              <option value="currentlyReading">Currently Reading</option>
                              <option value="wantToRead">Want to Read</option>
                              <option value="read">Read</option>
                              <option value="none">None</option>
                            </select>
                          </div>
                        </div>
                        <div className="book-title">{book.title}</div>
                        <div className="book-authors">{book.authors[0]}</div>
                      </div></li>)})}
                  </ol>
                </div>
              </div>
            </div>
          </div>
          <div className="open-search">
            <button href="" onClick={() => setShowSearchpage(!showSearchPage)}>Add a book</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
